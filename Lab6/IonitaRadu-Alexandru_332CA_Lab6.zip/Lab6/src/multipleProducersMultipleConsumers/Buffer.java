package multipleProducersMultipleConsumers;

import java.util.concurrent.ArrayBlockingQueue;

public class Buffer {
	ArrayBlockingQueue<Integer> a = new ArrayBlockingQueue(1);

	void put(int value) {
		try {
			a.put(value);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	int get() {
		try {
			return a.take();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return 0;

	}
}
